# Run log

One entry per scheduled run, newest last. Keep entries short.

Format:

    ## YYYY-MM-DD — <item or "no-op">
    - Did: ...
    - PR: #N, merged / open (why) / needs-conan (or none, and why)
    - Verification: green / what failed
    - Next: what the next run should pick up
    - Notes: anything surprising (also add to learnings.md if durable)
    - Catch-up: one sentence Conan should read even if he reads nothing else

## 2026-09-21 — baseline (set up by hand, not a scheduled run)
- Did: added CLAUDE.md and .claude/ backlog, log, learnings.
- Verification on `e44bd09`: go vet, ruff, validate, observability check, and
  29 pytest tests pass; `internal/audit`, `console`, `exec`, `fleet` pass;
  `internal/engine` fails 2 tests (ref coupling, see backlog #1).
  golangci-lint not run.
- Next: backlog #1.
- Switched to full auto-merge behind required CI checks (CLAUDE.md §2).
- Brief revised: agent now releases and deploys through the gates as the
  `claude-ops` operator identity and reports on production every run; work is
  sized per run by milestone, not by diff size.
- Moved to a cloud routine. Production access is now GitHub Actions with
  OIDC → IAM → SSM; there are no SSH keys and no credentials in the agent
  (CLAUDE.md §6).
