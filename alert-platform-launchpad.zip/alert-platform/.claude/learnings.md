# Learnings

Hard-won facts future runs should not have to rediscover. Append; don't
rewrite history.

- **SSH exit 255 is a transport failure, not an answer.** It was once read as
  "empty output", so `plan` saw an empty fleet and proposed creating every
  service. Fixed in `internal/exec/runner.go` (`checkSSHResult`, covered by
  `ssh255_test.go`). Any new remote read must distinguish "the command said
  nothing" from "the command never ran".
- **`alertctl` on the VM needs `sudo`.** Without it, reads of root-owned state
  come back empty and look like an empty fleet: the live reproduction of the
  255 class of bug.
- **Secrets resolve on the remote host, over SSH.** Local AWS env vars (even
  through `sudo -E`) are irrelevant; the host's credentials are what matter.
  Hence the IAM instance role.
- **Drift compares refs and unit hashes only.** In-place edits inside a
  release directory are invisible (backlog #6).
- **Tests that load the live `fleet/` specs are coupled to deployment
  decisions.** A ref bump in `e44bd09` broke two engine tests. Tests should own
  their fixtures.
- **Dependencies are vendored on purpose**: the control plane must build
  without network access during an incident. Always `go mod vendor`.
- **Validator and deploy gate are the same code** (`tools/validate.py`), so
  schema changes affect deploys immediately.
